// generated from rosidl_generator_c/resource/idl.h.em
// with input from flapper_messages:msg/Sphere.idl
// generated code does not contain a copyright notice

#ifndef FLAPPER_MESSAGES__MSG__SPHERE_H_
#define FLAPPER_MESSAGES__MSG__SPHERE_H_

#include "flapper_messages/msg/detail/sphere__struct.h"
#include "flapper_messages/msg/detail/sphere__functions.h"
#include "flapper_messages/msg/detail/sphere__type_support.h"

#endif  // FLAPPER_MESSAGES__MSG__SPHERE_H_
