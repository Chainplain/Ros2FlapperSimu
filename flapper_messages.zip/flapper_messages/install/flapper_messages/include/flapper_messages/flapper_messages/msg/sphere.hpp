// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FLAPPER_MESSAGES__MSG__SPHERE_HPP_
#define FLAPPER_MESSAGES__MSG__SPHERE_HPP_

#include "flapper_messages/msg/detail/sphere__struct.hpp"
#include "flapper_messages/msg/detail/sphere__builder.hpp"
#include "flapper_messages/msg/detail/sphere__traits.hpp"

#endif  // FLAPPER_MESSAGES__MSG__SPHERE_HPP_
